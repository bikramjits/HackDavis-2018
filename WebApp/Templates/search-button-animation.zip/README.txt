A Pen created at CodePen.io. You can find this one at https://codepen.io/kristyjy/pen/zGOXYb.

 Based on Dribbble: https://dribbble.com/shots/2026784-Search-Animation